# Excel_show_test

这是一个简单的excel样式的显示view  
项目中需要用到这样一个excel样式的展示，查找资料发现别人写的都不能满足需求，数据太多都会卡。所以自己写了一个。大家可以下载随意修改。欢迎修改，后续扩展功能在增加，

![image](https://github.com/JiangJiaXiang/Excel_show_test/blob/master/Excel_show_test/%E6%98%BE%E7%A4%BA.png)

有什么疑问和建议请联系我：2650477690@qq.com
