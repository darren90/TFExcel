//
//  LeftTableViewCell.h
//  Excel
//
//  Created by iosdev on 16/3/31.
//  Copyright © 2016年 Doer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *serialNumberLabel;

@end
