//
//  TopCollectionViewCell.m
//  Excel
//
//  Created by iosdev on 16/3/31.
//  Copyright © 2016年 Doer. All rights reserved.
//

#import "TopCollectionViewCell.h"

@implementation TopCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
