//
//  ContentCollectionViewCell.h
//  Excel
//
//  Created by iosdev on 16/3/18.
//  Copyright © 2016年 Doer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContentCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;

@end
