//
//  ContentCollectionViewCell.m
//  Excel
//
//  Created by iosdev on 16/3/18.
//  Copyright © 2016年 Doer. All rights reserved.
//

#import "ContentCollectionViewCell.h"

@implementation ContentCollectionViewCell

//- (id)initWithFrame:(CGRect)frame
//{
//    self= [super initWithFrame:frame];
//    if (self) {
//        
//        
//    }
//    return self;
//}

- (void)awakeFromNib {
    // Initialization code
    self.backgroundColor = [UIColor clearColor];

}



@end
