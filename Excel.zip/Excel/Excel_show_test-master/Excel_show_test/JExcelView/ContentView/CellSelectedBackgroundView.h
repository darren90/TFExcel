//
//  CellSelectedBackgroundView.h
//  IDoerTW
//
//  Created by iosdev on 16/3/22.
//  Copyright © 2016年 iosdev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellSelectedBackgroundView : UIView
- (id)initWithFrame:(CGRect)frame withLineWidth:(CGFloat)width withLineColor:(UIColor *)color;

@end
