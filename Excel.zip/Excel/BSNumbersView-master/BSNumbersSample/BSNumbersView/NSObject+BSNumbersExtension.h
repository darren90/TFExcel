//
//  NSObject+BSNumbersExtension.h
//  BSNumbersSample
//
//  Created by 张亚东 on 16/4/6.
//  Copyright © 2016年 blurryssky. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (BSNumbersExtension)

@property (strong, nonatomic, readonly) NSArray<NSString *> *bs_propertyValues;

@end
