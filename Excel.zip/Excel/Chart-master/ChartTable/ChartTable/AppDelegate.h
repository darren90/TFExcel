//
//  AppDelegate.h
//  ChartTable
//
//  Created by xun.liu on 15/5/25.
//  Copyright (c) 2015年 xun.liu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

