# ZFExcelChart
简单的数据展示图表，类似Excel那样分类分级统计数据，并可上下左右滑动查看数据
### 效果演示：
![image](https://github.com/renzifeng/ZFExcelChart/raw/master/screen.png)
# 期待
- 如果在使用过程中遇到BUG，或发现功能不够用，希望你能Issues我
- 如果觉得好用请Star!
- 谢谢!